import tensorflow as tf
import numpy as np
from sklearn.model_selection import train_test_split
import string
import pandas as pd
import json
from flask import Flask, request, jsonify
from flask_cors import CORS

# Inicializar la aplicación Flask y habilitar CORS
app = Flask(__name__)
CORS(app)  # Habilita CORS para todas las rutas

# Parámetros de configuración
MAX_TOKENS = 1000
SEQUENCE_LENGTH = 20
EMBEDDING_DIM = 128
NUM_FILTERS = 256
KERNEL_SIZE = 5
DROPOUT_RATE = 0.6
EPOCHS = 50
BATCH_SIZE = 16

# Importar datos (asegúrate de tener el archivo datos.py con las variables necesarias)
from datos import comentarios, palabras_negativas, palabras_positivas

# Generar etiquetas correspondientes (0 = negativo, 1 = positivo)
etiquetas = np.array([0] * 100 + [1] * 100, dtype=int)

# Función para contar palabras clave en un texto
def contar_palabras_clave(texto, palabras):
    return sum(1 for palabra in palabras if palabra in texto)

# Función de preprocesamiento de texto: convierte a minúsculas y elimina la puntuación
def preprocess_text(text):
    return ''.join([char.lower() for char in text if char not in string.punctuation])

# Preprocesar comentarios
comentarios = [preprocess_text(c) for c in comentarios]

# Vectorización de texto
vectorizer = tf.keras.layers.TextVectorization(
    max_tokens=MAX_TOKENS,
    output_sequence_length=SEQUENCE_LENGTH
)
vectorizer.adapt(comentarios)
comentarios_encoded = vectorizer(comentarios).numpy()  # Corregido: comentarios_encoded en lugar de comentarios_encoded

# Crear características adicionales (conteo de palabras clave)
X_palabras_clave = np.array([
    [contar_palabras_clave(texto, palabras_positivas),
     contar_palabras_clave(texto, palabras_negativas)]
    for texto in comentarios
])

# Combinar características (texto vectorizado + palabras clave)
X_combinado = np.concatenate([comentarios_encoded, X_palabras_clave], axis=1)
print(f"Forma de X_combinado: {X_combinado.shape}")  # Debe ser (200, SEQUENCE_LENGTH + 2)

# División de datos en entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(
    X_combinado, etiquetas, test_size=0.2, random_state=42
)

# Definición del modelo
modelo = tf.keras.Sequential([
    tf.keras.layers.Embedding(input_dim=MAX_TOKENS, output_dim=EMBEDDING_DIM, input_length=SEQUENCE_LENGTH),
    tf.keras.layers.Conv1D(NUM_FILTERS, KERNEL_SIZE, activation='relu'),
    tf.keras.layers.GlobalMaxPooling1D(),
    tf.keras.layers.Dense(64, activation='relu', kernel_regularizer=tf.keras.regularizers.l2(0.01)),
    tf.keras.layers.Dropout(DROPOUT_RATE),
    tf.keras.layers.Dense(1, activation='sigmoid')
])

modelo.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001),
    loss='binary_crossentropy',
    metrics=['accuracy']
)

# Entrenamiento del modelo
print("Entrenando el modelo...")
historial = modelo.fit(
    X_train, y_train,
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    validation_data=(X_test, y_test),
    verbose=1
)

# Guardar el modelo entrenado
modelo.save("modelo_sentimiento.h5")
print("Modelo guardado como 'modelo_sentimiento.h5'.")

# Guardar el vocabulario del vectorizador
vocabulario = vectorizer.get_vocabulary()
with open("vocabulario.json", "w") as f:
    json.dump(vocabulario, f)
print("Vocabulario guardado como 'vocabulario.json'.")

# ----------------- Implementación de la API Flask -----------------

# Cargar el modelo y el vectorizador
try:
    modelo = tf.keras.models.load_model("modelo_sentimiento.h5")
    with open("vocabulario.json", "r") as f:
        vocabulario_guardado = json.load(f)
    vectorizer = tf.keras.layers.TextVectorization(
        max_tokens=MAX_TOKENS,
        output_sequence_length=SEQUENCE_LENGTH,
        vocabulary=vocabulario_guardado
    )
    print("Modelo y vocabulario cargados exitosamente.")
except FileNotFoundError as e:
    print(f"Error: No se encontró el archivo. {e}")
    exit(1)

# Ruta para analizar un comentario
@app.route('/analizar', methods=['POST'])
def analizar_comentario():
    data = request.json
    comentario = data['comentario']
    
    comentario_procesado = preprocess_text(comentario)
    comentario_encoded = vectorizer([comentario_procesado])
    prediccion = modelo.predict(comentario_encoded)[0][0]
    umbral = 0.4  # Umbral ajustable
    if prediccion > umbral:
        return jsonify({"clasificacion": "Positivo", "probabilidad": float(prediccion)})
    else:
        return jsonify({"clasificacion": "Negativo", "probabilidad": float(prediccion)})

# Ruta para cargar y analizar un archivo Excel
@app.route('/analizar_excel', methods=['POST'])
def analizar_excel():
    if 'file' not in request.files:
        return jsonify({"error": "No se proporcionó ningún archivo"}), 400
    
    file = request.files['file']
    try:
        df = pd.read_excel(file)
        if 'Comentarios' not in df.columns:
            return jsonify({"error": "El archivo Excel debe tener una columna llamada 'Comentarios'"}), 400
        
        resultados = []
        for comentario in df['Comentarios']:
            comentario_procesado = preprocess_text(comentario)
            comentario_encoded = vectorizer([comentario_procesado])
            prediccion = modelo.predict(comentario_encoded)[0][0]
            umbral = 0.4  # Umbral ajustable
            if prediccion > umbral:
                resultados.append({"comentario": comentario, "clasificacion": "Positivo", "probabilidad": float(prediccion)})
            else:
                resultados.append({"comentario": comentario, "clasificacion": "Negativo", "probabilidad": float(prediccion)})
        
        return jsonify(resultados)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    # Entrenar el modelo y guardar los archivos
    print("Entrenamiento completado. Iniciando la API Flask...")
    app.run(debug=True)