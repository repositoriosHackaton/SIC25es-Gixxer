from flask import Flask, request, jsonify
from textblob import TextBlob
from flask_cors import CORS

app = Flask(__name__)
CORS(app)


def analizar_sentimiento(texto):
    """Analiza el sentimiento del comentario."""
    if not texto:
        return "Error", "Comentario vacío"
    
    analisis = TextBlob(texto)
    polaridad = analisis.sentiment.polarity
    
    if polaridad > 0:
        clasificacion = "Positivo"
    elif polaridad < 1:
        clasificacion = "Negativo"
    else:
        clasificacion = "Neutral"
    
    # Se añade la probabilidad como el valor absoluto de la polaridad.
    probabilidad = round(abs(polaridad), 2)
    return clasificacion, probabilidad

@app.route('/analizar', methods=['POST'])
def analizar():
    """Recibe un comentario y devuelve su clasificación y probabilidad."""
    try:
        datos = request.get_json()
        comentario = datos.get("comentario", "").strip()
        
        if not comentario:
            return jsonify({"error": "El comentario está vacío o no fue proporcionado"}), 400
        
        clasificacion, probabilidad = analizar_sentimiento(comentario)
        
        if clasificacion == "Error":
            return jsonify({"error": probabilidad}), 400

        return jsonify({"clasificacion": clasificacion, "probabilidad": probabilidad})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)